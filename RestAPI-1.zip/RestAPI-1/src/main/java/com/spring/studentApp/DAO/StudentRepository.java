package com.spring.studentApp.DAO;
import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.studentApp.model.Student;

public interface StudentRepository extends JpaRepository<Student, Long>{

}
