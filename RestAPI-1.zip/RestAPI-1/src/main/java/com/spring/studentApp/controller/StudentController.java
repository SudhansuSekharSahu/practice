package com.spring.studentApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.studentApp.DAO.StudentRepository;
import com.spring.studentApp.model.Student;

@RestController
public class StudentController {
	
	@Autowired
	private StudentRepository studentRepository;
	
	@GetMapping("/student")
	public List<Student> getAllStudent() {
		return studentRepository.findAll();
	}

	@PostMapping("/student")
	public Student addStudent(@RequestBody Student newStudent) {
		studentRepository.save(newStudent);
		return newStudent;
	}
	
	@GetMapping("/stuednt/{id}")
	public Student getByStudentId(@PathVariable Long id) {
		return studentRepository.getOne(id);
	}
	
	@DeleteMapping("/student/{id}")
	public ResponseEntity<?> deleteStudent(@Validated @PathVariable Long id) {
		
	if(studentRepository.findById(id).isPresent()) {
		studentRepository.deleteById(id);
		return ResponseEntity.ok().build();
	}
	else 
		return (ResponseEntity<?>) ResponseEntity.noContent();
		
//		return studentRepository.findById(id).map(student ->{
//			studentRepository.delete(student);
//			return ResponseEntity.ok().build();
//		}).orElseThrow(() -> new ResourceNotFoundException("Student not found with id "+ id));
//		
	}
}
